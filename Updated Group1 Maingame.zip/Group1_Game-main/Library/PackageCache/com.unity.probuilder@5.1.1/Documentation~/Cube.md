# Cube
A cube is the default shape in ProBuilder. It is a six-sided 3D square. 

![Cube shapes](images/shape-tool_cube.png)

The cube shape has no shape-specific properties.


