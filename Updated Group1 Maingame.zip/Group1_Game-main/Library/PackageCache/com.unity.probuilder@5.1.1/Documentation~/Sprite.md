# Sprite
In ProBuilder, a sprite shape is a [plane](Plane.md) with all values set to 1 unit. 

![Sprite shape](images/shape-tool_sprite.png)

The sprite shape has no shape-specific properties.
